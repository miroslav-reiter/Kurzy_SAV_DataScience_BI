# HDP hrubý domáci produkt krajin dataset
# GDP

import streamlit as st
import pandas as pd
import math
from pathlib import Path

# Nastavenie názvu a ikonky, ktoré sa zobrazujú v záložke prehliadača.
st.set_page_config(
    page_title='HDP dashboard',
    page_icon=':earth_americas:', # Toto je skratka pre emoji. Môže to byť aj URL.
)

# ---------------------------------------------------------------------------
# Definovanie niektorých užitočných funkcií.

@st.cache_data
def get_gdp_data():
    """Načítanie údajov o HDP z CSV súboru.

    Toto využíva cache, aby sa zabránilo načítavaniu súboru zakaždým. Ak by sme
    čítali z HTTP endpointu namiesto súboru, je vhodné nastaviť maximálny vek cache
    pomocou argumentu TTL: @st.cache_data(ttl='1d')
    """

    # Namiesto CSV na disku môžete čítať aj z HTTP endpointu.
    DATA_FILENAME = Path(__file__).parent/'data/gdp_data.csv'
    raw_gdp_df = pd.read_csv(DATA_FILENAME)

    MIN_YEAR = 1960
    MAX_YEAR = 2022

    # Dáta majú stĺpce ako:
    # - Názov krajiny
    # - Kód krajiny
    # - [Veci, na ktorých mi nezáleží]
    # - HDP pre 1960
    # - HDP pre 1961
    # - HDP pre 1962
    # - ...
    # - HDP pre 2022
    #
    # ...ale ja chcem toto:
    # - Názov krajiny
    # - Kód krajiny
    # - Rok
    # - HDP
    #
    # Takže teraz preformátujeme všetky roky do dvoch stĺpcov: Rok a HDP
    gdp_df = raw_gdp_df.melt(
        ['Country Code'],
        [str(x) for x in range(MIN_YEAR, MAX_YEAR + 1)],
        'Year',
        'GDP',
    )

    # Prevedenie rokov zo stringov na celé čísla
    gdp_df['Year'] = pd.to_numeric(gdp_df['Year'])

    return gdp_df

gdp_df = get_gdp_data()

# ---------------------------------------------------------------------------
# Vytvorenie samotnej stránky

# Nastavenie nadpisu, ktorý sa zobrazí na vrchnej časti stránky.
'''
# :earth_americas: HDP dashboard

Prezerajte si údaje o HDP z webu [World Bank Open Data](https://data.worldbank.org/). Ako si všimnete, údaje idú len do roku 2022 a niektoré roky môžu chýbať. Napriek tomu je to skvelý (a spomenul som _zadarmo_?) zdroj údajov.
'''

# Pridanie medzier
''
''

min_value = gdp_df['Year'].min()
max_value = gdp_df['Year'].max()

from_year, to_year = st.slider(
    'O ktoré roky máte záujem?',
    min_value=min_value,
    max_value=max_value,
    value=[min_value, max_value])

countries = gdp_df['Country Code'].unique()

if not len(countries):
    st.warning("Vyberte aspoň jednu krajinu")

selected_countries = st.multiselect(
    'Ktoré krajiny by ste chceli vidieť?',
    countries,
    ['DEU', 'FRA', 'GBR', 'BRA', 'MEX', 'JPN'])

''
''
''

# Filtrovanie údajov
filtered_gdp_df = gdp_df[
    (gdp_df['Country Code'].isin(selected_countries))
    & (gdp_df['Year'] <= to_year)
    & (from_year <= gdp_df['Year'])
]

st.header('HDP v priebehu rokov', divider='gray')

''

st.line_chart(
    filtered_gdp_df,
    x='Year',
    y='GDP',
    color='Country Code',
)

''
''


first_year = gdp_df[gdp_df['Year'] == from_year]
last_year = gdp_df[gdp_df['Year'] == to_year]

st.header(f'HDP v roku {to_year}', divider='gray')

''

cols = st.columns(4)

for i, country in enumerate(selected_countries):
    col = cols[i % len(cols)]

    with col:
        first_gdp = first_year[first_year['Country Code'] == country]['GDP'].iat[0] / 1000000000
        last_gdp = last_year[last_year['Country Code'] == country]['GDP'].iat[0] / 1000000000

        if math.isnan(first_gdp):
            growth = 'n/a'
            delta_color = 'off'
        else:
            growth = f'{last_gdp / first_gdp:,.2f}x'
            delta_color = 'normal'

        st.metric(
            label=f'{country} HDP',
            value=f'{last_gdp:,.0f}B',
            delta=growth,
            delta_color=delta_color
        )

# ----------------------------------------------------------------------

# Tento kód vytvára jednoduchý interaktívny panel pre zobrazenie údajov o HDP (hrubý domáci produkt) jednotlivých krajín v rôznych rokoch pomocou knižnice Streamlit.

# Preloženie a vysvetlenie:
# Importovanie knižníc:

import plotly.express as px

# Horizontálny stĺpcový graf pre vybrané krajiny
st.header('Horizontálny stĺpcový graf HDP za posledný rok')

# Vezmeme posledný rok v rozsahu
last_year_data = filtered_gdp_df[filtered_gdp_df['Year'] == to_year]

# Vytvorenie horizontálneho stĺpcového grafu
fig_bar = px.bar(
    last_year_data,
    x='GDP',
    y='Country Code',
    orientation='h',
    title=f'HDP krajín v roku {to_year}',
    labels={'GDP': 'HDP', 'Country Code': 'Krajina'},
)

st.plotly_chart(fig_bar)

# Krabicové grafy pre Slovensko a Česko
st.header('Krabicové grafy HDP pre Slovensko a Česko')

# Filtrovanie údajov pre Slovensko a Česko
slovakia_data = gdp_df[gdp_df['Country Code'] == 'SVK']
czech_data = gdp_df[gdp_df['Country Code'] == 'CZE']

# Vytvorenie krabicových grafov pre Slovensko a Česko pomocou pd.concat
combined_data = pd.concat([slovakia_data, czech_data])

# Vytvorenie krabicového grafu
fig_box = px.box(
    combined_data,
    x='Country Code',
    y='GDP',
    title='Porovnanie HDP Slovenska a Česka',
    labels={'GDP': 'HDP', 'Country Code': 'Krajina'},
)

st.plotly_chart(fig_box)
