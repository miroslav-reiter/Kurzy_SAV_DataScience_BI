# HDP hrubý domáci produkt krajin dataset
# GDP

import streamlit as st
import pandas as pd
import math
from pathlib import Path

# Nastavenie názvu a ikonky, ktoré sa zobrazujú v záložke prehliadača.


# ---------------------------------------------------------------------------
# Definovanie niektorých užitočných funkcií.



    # Namiesto CSV na disku môžete čítať aj z HTTP endpointu.



    # Dáta majú stĺpce ako:
    # - Názov krajiny
    # - Kód krajiny
    # - [Veci, na ktorých mi nezáleží]
    # - HDP pre 1960
    # - HDP pre 1961
    # - HDP pre 1962
    # - ...
    # - HDP pre 2022
    #
    # ...ale ja chcem toto:
    # - Názov krajiny
    # - Kód krajiny
    # - Rok
    # - HDP
    #
    # Takže teraz preformátujeme všetky roky do dvoch stĺpcov: Rok a HDP



    # Prevedenie rokov zo stringov na celé čísla



# ---------------------------------------------------------------------------
# Vytvorenie samotnej stránky

# Nastavenie nadpisu, ktorý sa zobrazí na vrchnej časti stránky.



# Pridanie medzier






# Filtrovanie údajov








# ----------------------------------------------------------------------



# Horizontálny stĺpcový graf pre vybrané krajiny


# Vezmeme posledný rok v rozsahu



# Vytvorenie horizontálneho stĺpcového grafu





# Krabicové grafy pre Slovensko a Česko


# Filtrovanie údajov pre Slovensko a Česko


# Vytvorenie krabicových grafov pre Slovensko a Česko pomocou pd.concat



# Vytvorenie krabicového grafu
