# 🎬 Filmy dataset

import altair as alt
import pandas as pd
import streamlit as st

# Zobraziť názov stránky a popis.


# Načítajte údaje z CSV. Ukladáme to do vyrovnávacej pamäte, aby sa nenačítalo znova pri každom spustení aplikácie (napr. ak používateľ interaguje s miniaplikáciami).


# Zobrazte miniaplikáciu s viacerými výbermi so žánrami pomocou `st.multiselect`.


# Zobrazte miniaplikáciu jazdca s rokmi pomocou `st.slider`.


# Filtrujte dátový rámec na základe vstupu widgetu a pretvorte ho.


# Zobrazte údaje ako tabuľku pomocou `st.dataframe`.



# Zobrazte údaje ako Altairovu tabuľku pomocou `st.altair_chart`.



# Pridajte stĺpcový graf s celkovými zárobkami podľa žánru.


# Pridanie textových popisov do stĺpcového grafu



# Pridajte koláčový graf pre rozdelenie zárobkov podľa žánru s percentami.



# Pridanie textových popisov do koláčového grafu s percentami vo vnútri

