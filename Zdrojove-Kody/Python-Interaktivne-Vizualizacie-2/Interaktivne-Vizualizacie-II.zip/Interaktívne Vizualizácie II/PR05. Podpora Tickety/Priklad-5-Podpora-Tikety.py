import datetime
import random

import altair as alt
import numpy as np
import pandas as pd
import streamlit as st
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# Zobrazenie názvu aplikácie a popisu.
st.set_page_config(page_title="Technická podpora tikety", page_icon="🎫")
st.title("🎫 Technická podpora tikety")
st.write(
    """
    Táto aplikácia ukazuje, ako si môžete vytvoriť interný nástroj v Streamlite. 
    Tu implementujeme pracovný postup podporných lístkov. Používateľ môže vytvoriť tiket, 
    upraviť existujúce tikety a zobraziť niektoré štatistiky.
    """
)

# Vytvorenie náhodného Pandas dataframe s existujúcimi tiketmi.
if "df" not in st.session_state:

    # Nastavenie semena pre reprodukovateľnosť.
    np.random.seed(42)

    # Vytvorenie falošných popisov problémov.
    issue_descriptions = [
        "Problémy s pripojením na internet v kancelárii",
        "Aplikačný softvér padá pri spustení",
        "Tlačiareň neodpovedá na príkazy na tlač",
        "Výpadok e-mailového servera",
        "Zlyhanie zálohovania dát",
        "Problémy s autentifikáciou pri prihlasovaní",
        "Zníženie výkonu webovej stránky",
        "Identifikovaná bezpečnostná zraniteľnosť",
        "Porucha hardvéru v serverovej miestnosti",
        "Zamestnanec nemôže pristupovať k zdieľaným súborom",
        "Chyba pripojenia k databáze",
        "Mobilná aplikácia nesynchronizuje dáta",
        "Problémy s VoIP telefónnym systémom",
        "Problémy s VPN pripojením pre vzdialených zamestnancov",
        "Aktualizácie systému spôsobujú problémy s kompatibilitou",
        "Súborový server má nedostatok úložného priestoru",
        "Upozornenia systému detekcie prienikov",
        "Chyby v systéme riadenia inventára",
        "Dáta zákazníkov sa nenačítavajú v CRM",
        "Nástroj na spoluprácu neposiela upozornenia"
    ]

    # Vygenerovanie dataframe s 100 riadkami/tiketmi.
    data = {
        "ID": [f"TIKET-{i}" for i in range(1100, 1000, -1)],
        "Problém": np.random.choice(issue_descriptions, size=100),
        "Stav": np.random.choice(["Otvorené", "V riešení", "Uzatvorené"], size=100),
        "Priorita": np.random.choice(["Vysoká", "Stredná", "Nízka"], size=100),
        "Dátum podania": [
            datetime.date(2023, 6, 1) + datetime.timedelta(days=random.randint(0, 182))
            for _ in range(100)
        ],
    }
    df = pd.DataFrame(data)

    # Uloženie dataframe do session state (objekt podobný slovníku, ktorý pretrváva
    # medzi spusteniami stránky). Toto zabezpečuje, že naše dáta zostanú zachované, keď sa aplikácia aktualizuje.
    st.session_state.df = df

# Zobrazenie sekcie na pridanie nového tiketu.
st.header("Pridať tiket")

# Pridávame tikety cez `st.form` a niektoré vstupné widgety. Ak sú widgety použité 
# vo formulári, aplikácia sa obnoví až po stlačení tlačidla odoslať.
with st.form("add_ticket_form"):
    issue = st.text_area("Opíšte problém")
    priority = st.selectbox("Priorita", ["Vysoká", "Stredná", "Nízka"])
    submitted = st.form_submit_button("Odoslať")

if submitted:
    # Vytvorenie dataframe pre nový tiket a pripojenie ho k dataframe v session state.
    recent_ticket_number = int(max(st.session_state.df.ID).split("-")[1])
    today = datetime.datetime.now().strftime("%m-%d-%Y")
    df_new = pd.DataFrame(
        [
            {
                "ID": f"TIKET-{recent_ticket_number+1}",
                "Problém": issue,
                "Stav": "Otvorené",
                "Priorita": priority,
                "Dátum podania": today,
            }
        ]
    )

    # Zobrazenie správy o úspešnom pridaní tiketu.
    st.write("Tiket bol odoslaný! Tu sú detaily tiketu:")
    st.dataframe(df_new, use_container_width=True, hide_index=True)
    st.session_state.df = pd.concat([df_new, st.session_state.df], axis=0)

# Zobrazenie sekcie na prezeranie a úpravu existujúcich tiketov v tabuľke.
st.header("Existujúce tikety")
st.write(f"Počet tiketov: `{len(st.session_state.df)}`")

st.info(
    "Tikety môžete upravovať dvojitým kliknutím na bunku. Sledujte, ako sa grafy nižšie "
    "automaticky aktualizujú! Tiež môžete triediť tabuľku kliknutím na hlavičky stĺpcov.",
    icon="✍️",
)

# Zobrazenie dataframe tiketov pomocou `st.data_editor`.
edited_df = st.data_editor(
    st.session_state.df,
    use_container_width=True,
    hide_index=True,
    column_config={
        "Stav": st.column_config.SelectboxColumn(
            "Stav",
            help="Stav tiketu",
            options=["Otvorené", "V riešení", "Uzatvorené"],
            required=True,
        ),
        "Priorita": st.column_config.SelectboxColumn(
            "Priorita",
            help="Priorita",
            options=["Vysoká", "Stredná", "Nízka"],
            required=True,
        ),
    },
    disabled=["ID", "Dátum podania"],
)

# Zobrazenie niektorých metrík a grafov o tiketoch.
st.header("Štatistiky")

# Zobrazenie metrík vedľa seba pomocou `st.columns` a `st.metric`.
col1, col2, col3 = st.columns(3)
num_open_tickets = len(st.session_state.df[st.session_state.df.Stav == "Otvorené"])
col1.metric(label="Počet otvorených tiketov", value=num_open_tickets, delta=10)
col2.metric(label="Prvý čas odozvy (v hodinách)", value=5.2, delta=-1.5)
col3.metric(label="Priemerný čas vyriešenia (v hodinách)", value=16, delta=2)

# Rozšírená metrika úspešnosti riešenia
num_resolved_tickets = len(st.session_state.df[st.session_state.df.Stav == "Uzatvorené"])
total_tickets = len(st.session_state.df)
resolution_success = (num_resolved_tickets / total_tickets) * 100 if total_tickets > 0 else 0
st.metric(label="Úspešnosť riešenia (%)", value=f"{resolution_success:.2f}%")

# Heatmapa priorít v čase
st.write("##### Heatmapa Priorít v Čase")
df_filtered = edited_df.copy()
df_filtered["Mesiac"] = pd.to_datetime(df_filtered["Dátum podania"]).dt.strftime('%B')

priority_heatmap = alt.Chart(df_filtered).mark_rect().encode(
    x=alt.X("Mesiac:N", title="Mesiac"),
    y=alt.Y("Priorita:N", title="Priorita"),
    color=alt.Color('count():Q', scale=alt.Scale(scheme='inferno'), title="Počet tiketov"),
    tooltip=["Mesiac", "Priorita", "count()"]
).properties(
    width=600,
    height=400
)
st.altair_chart(priority_heatmap, use_container_width=True)

# Word cloud – najčastejšie problémy
st.write("##### Word Cloud – Najčastejšie Problémy")
problem_text = " ".join(st.session_state.df['Problém'].values)
wordcloud = WordCloud(background_color='white').generate(problem_text)


plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
st.pyplot(plt)
