import datetime
import random

import altair as alt
import numpy as np
import pandas as pd
import streamlit as st
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# Zobrazenie názvu aplikácie a popisu.


# Vytvorenie náhodného Pandas dataframe s existujúcimi tiketmi.


    # Nastavenie semena pre reprodukovateľnosť.
     

    # Vytvorenie falošných popisov problémov.
     

    # Vygenerovanie dataframe s 100 riadkami/tiketmi.
     

    # Uloženie dataframe do session state (objekt podobný slovníku, ktorý pretrváva
    # medzi spusteniami stránky). Toto zabezpečuje, že naše dáta zostanú zachované, keď sa aplikácia aktualizuje.
     

# Zobrazenie sekcie na pridanie nového tiketu.


# Pridávame tikety cez `st.form` a niektoré vstupné widgety. Ak sú widgety použité 
# vo formulári, aplikácia sa obnoví až po stlačení tlačidla odoslať.




    # Vytvorenie dataframe pre nový tiket a pripojenie ho k dataframe v session state.
    

    # Zobrazenie správy o úspešnom pridaní tiketu.
    
    

# Zobrazenie sekcie na prezeranie a úpravu existujúcich tiketov v tabuľke.




# Zobrazenie dataframe tiketov pomocou `st.data_editor`.



# Zobrazenie niektorých metrík a grafov o tiketoch.


# Zobrazenie metrík vedľa seba pomocou `st.columns` a `st.metric`.



# Rozšírená metrika úspešnosti riešenia


# Heatmapa priorít v čase




# Word cloud – najčastejšie problémy

