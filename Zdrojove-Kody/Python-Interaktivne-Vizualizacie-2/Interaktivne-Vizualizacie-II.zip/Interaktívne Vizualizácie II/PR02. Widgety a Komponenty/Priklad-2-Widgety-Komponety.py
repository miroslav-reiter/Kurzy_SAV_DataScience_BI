import streamlit as st
import pandas as pd
import datetime
import time
from PIL import Image

st.write(
    "# 🤯 1. Nadpis (Title)"
)

st.title("🎈 Moja nová aplikácia")

st.write(
    "# 🔠 2. Text (Text)"
)

st.write(
    "Let's start building! For help and inspiration, head over to [docs.streamlit.io](https://docs.streamlit.io/)."
)

st.write(
    "# ▶️ 3. Tlačidlo (Button)"
)

if st.button('Klikni ma'):
    st.write('Tlačidlo bolo stlačené!')

st.write(
    "# 🛝 4. Posuvník (slider)"
)

číslo = st.slider('Vyber číslo', 0, 100)
st.write(f'Vybrané číslo je: {číslo}')

st.write(
    "# ✍ 5. Textový vstup (Text Input)"
)

meno = st.text_input('Zadajte svoje meno:')
st.write(f'Ahoj, {meno}!')

st.write(
    "# ☑️ 6. Zaškrtávacie políčko. (Checkbox)"
)

akcia = st.checkbox('Zobraziť text')
if akcia:
    st.write('Text je zobrazený')

st.write(
    "# 🔽 7. Rozbaľovací zoznam s možnosťami. (Selectbox)"
)

voľba = st.selectbox('Vyberte možnosť:', ['Možnosť 1', 'Možnosť 2', 'Možnosť 3'])
st.write(f'Vybrali ste: {voľba}')

st.write(
    "# 📁 8. Upload súborov. (File uploader)"
)

súbor = st.file_uploader('Nahrajte súbor')
if súbor is not None:
    st.write('Súbor úspešne nahraný!')

st.write(
    "# 🔥 9. Upload CSV súborov. (File CSV uploader)"
)

# Vytvorenie uploadovacieho widgetu
uploaded_file = st.file_uploader("Nahrajte CSV súbor s filmami", type="csv")

# Kontrola, či bol súbor nahratý
if uploaded_file is not None:
    # Načítanie CSV súboru pomocou pandas
    df = pd.read_csv(uploaded_file)

    # Zobrazenie dát v tabuľke
    st.write("Tu sú vaše filmy:")
    st.dataframe(df)

st.write(
    "# 🏁 10. Upload obrázkov. (File image uploader)"
)

# Nahratie obrázku
uploaded_file = st.file_uploader("Nahrajte obrázok", type=["jpg", "png"])

# Zobrazenie obrázku
if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption="Nahratý obrázok", use_column_width=True)

# Vytvorenie vzorového datasetu
df = pd.DataFrame({
    'Meno': ['Peter', 'Jana', 'Martin'],
    'Vek': [30, 25, 40]
})

st.write(
    "# 📥 11. Tlačidlo na stiahnutie. (Download button)"
)

# Konvertovanie DataFrame do CSV
csv = df.to_csv(index=False)

# Tlačidlo na stiahnutie CSV súboru
st.download_button(
    label="Stiahnuť CSV",
    data=csv,
    file_name='data.csv',
    mime='text/csv',
)

st.write(
    "# 📻 12. Výber jednej možnosti. (Radio)"
)

# Vytvorenie widgetu radio button
voľba = st.radio(
    "Vyberte si obľúbený žáner filmu:",
    ('Akčný', 'Komedie', 'Dráma')
)

# Zobrazenie zvolenej možnosti
if voľba == 'Akčný':
    st.write('Vybrali ste si Akčný film.')
elif voľba == 'Komedie':
    st.write('Vybrali ste si Komediu.')
else:
    st.write('Vybrali ste si Drámu.')

st.write(
    "# 🗳️ 13. Výber viacerých možností. (Multiselect)"
)

# Vytvorenie widgetu multiselect
vybrané_filmy = st.multiselect(
    'Vyberte svoje obľúbené filmy',
    ['Matrix', 'Pán prsteňov', 'Titanic', 'Star Wars', 'Inception'],
    placeholder='Vyberte film, ktorý sa vám páči'
)

# Zobrazenie vybraných filmov
st.write(f'Vybrali ste: {", ".join(vybrané_filmy)}')

st.write(
    "# 📅 14. Výber dátumu. (Date input)"
)

# Vytvorenie widgetu na výber dátumu
dátum = st.date_input(
    "Vyberte dátum",
    datetime.date(2023, 1, 1)
)

# Zobrazenie vybraného dátumu
st.write('Vybrali ste dátum:', dátum)

st.write(
    "# 🕔 15. Výber času. (Time input)"
)

# Vytvorenie widgetu na výber času
čas = st.time_input('Zadajte čas', datetime.time(8, 45))

# Zobrazenie vybraného času
st.write('Vybrali ste čas:', čas)

st.write(
    "# 🅰 16. Vstup dlhšieho textu. (Text area)"
)

# Vytvorenie widgetu text area
text = st.text_area('Napíšte svoj názor na film', 'Zadajte text sem...')

# Zobrazenie zadaného textu
st.write('Váš názor:', text)

st.write(
    "# 🔢 17. Vstup číselnej hodnoty. (Number Input)"
)

# Vytvorenie widgetu na zadávanie čísel
hodnotenie = st.number_input('Zadajte hodnotenie filmu (od 1 do 10)', min_value=1, max_value=10, value=5)

# Zobrazenie hodnotenia
st.write(f'Vaše hodnotenie: {hodnotenie}/10')

st.write(
    "# 🎚️ 18. Posuvník s výberom. (Select Slider)"
)

# Vytvorenie posuvníka s vlastnými hodnotami
stupnica = st.select_slider(
    'Ako veľmi sa vám páčil film?',
    options=['Hrozné', 'Slabé', 'Priemerné', 'Dobre', 'Výborné']
)

# Zobrazenie vybranej stupnice
st.write('Vaše hodnotenie:', stupnica)

st.write(
    "# 🔴 19. Výber farby (Color picker)"
)

# Vytvorenie widgetu na výber farby
farba = st.color_picker('Vyberte farbu pozadia', '#00f900')

# Zobrazenie zvolenej farby
st.write('Zvolili ste farbu:', farba)

st.write(
    "# ⏳ 20. Indikátor progresu (Progress)"
)

# # Indikátor progresu
# progres = st.progress(0)

# for i in range(100):
#     time.sleep(0.05)
#     progres.progress(i + 1)

st.write(
    "# 📐 21. Zobrazenie LaTeXu (matematické výrazy) (latex)"
)

# Zobrazenie matematického výrazu pomocou LaTeXu
st.latex(r'''
     a^2 + b^2 = c^2
     ''')

st.write(
    "# 🌍 22. Zobrazenie kódu s formátovaním (code)"
)

# Zobrazenie kódu
st.code('''
def ahoj():
    print("Ahoj, Streamlit!")
''', language='python')

st.write(
    "# 🌐 23. Zobrazenie JSON dát (json)"
)

# Zobrazenie JSON dát
data = {
    'meno': 'Peter',
    'vek': 30,
    'zamestnanie': 'programátor'
}
st.json(data)

st.write(
    "# ➡️ 24. Dynamický widget (všestranný) (write)"
)

# Zobrazenie viacerých typov dát
st.write("Textový reťazec")
st.write(123)
st.write({'kľúč': 'hodnota'})

st.write(
    "# 📏 25. Zobrazenie kľúčových metrik (metric)"
)

# Zobrazenie metriky
st.metric(label="Teplota", value="24°C", delta="2°C")

st.write(
    "# ❌ 26. Zobrazenie chybovej správy (error)"
)

# Zobrazenie chybovej správy
st.error("Toto je chybové hlásenie!")

st.write(
    "# ✅ 27. Zobrazenie úspešnej správy (success)"
)

# Zobrazenie úspešnej správy
st.success("Úloha bola úspešne dokončená!")

st.write(
    "# ⚠️ 28. Zobrazenie varovnej správy (warning)"
)

# Zobrazenie varovania
st.warning("Toto je varovanie!")

st.write(
    "# 🆗 29. Zobrazenie informatívnej správy (info)"
)

# Zobrazenie informatívnej správy
st.info("Toto je informatívna správa.")


st.write(
    "# ❗ 30. Zobrazenie výnimky (chyby v kóde) (exception)"
)

# Zobrazenie výnimky
# try:
#     1 / 0
# except ZeroDivisionError as e:
#     st.exception(e)


st.write(
    "# 🌀 31. Zobrazenie spinneru počas načítavania (spinner)"
)

# Spinner počas načítavania
with st.spinner('Čakajte prosím...'):
    time.sleep(3)
st.success('Hotovo!')

st.write(
    "# 📝 32. Zobrazenie textovej poznámky (caption)"
)

# Zobrazenie poznámky
st.caption('Toto je poznámka alebo vysvetlenie.')

st.write(
    "# 🖼️ 33. Zobrazenie obrázkov (image)"
)

# Zobrazenie obrázku
st.image("https://eurocc.nscc.sk/wp-content/uploads/2020/12/CC_EURO-_logo_gold-1.png", caption='Logo NSC')

st.write(
    "# 🎞️ 34. Zobrazenie videa/audio (video/audio)"
)

# Zobrazenie videa
st.video("https://www.youtube.com/watch?v=xG5X5n9cmHg")

st.write(
    "# 🏛️ 35. Rozdelenie obrazovky do stĺpcov (columns)"
)

# Vytvorenie 3 stĺpcov
col1, col2, col3 = st.columns(3)

with col1:
    st.write("Stĺpec 1")

with col2:
    st.write("Stĺpec 2")

with col3:
    st.write("Stĺpec 3")

st.write(
    "# 📑 36. Vytváranie záložiek/tabov (tabs)"
)

# Vytvorenie záložiek
tab1, tab2, tab3 = st.tabs(["Tab 1", "Tab 2", "Tab 3"])

with tab1:
    st.write("Obsah pre záložku 1")

with tab2:
    st.write("Obsah pre záložku 2")

with tab3:
    st.write("Obsah pre záložku 3")

st.write(
    "# 🚀 37. Rozbalovací blok (expander)"
)

# Vytvorenie expanderu
with st.expander("Kliknite sem pre viac informácií"):
    st.write("Toto je rozbalený obsah.")

st.write(
    "# 📈 38. Zobrazenie grafov v Matplotlib (pyplot)"
)

import matplotlib.pyplot as plt
# Vytvorenie jednoduchého grafu
fig, ax = plt.subplots()
ax.plot([1, 2, 3], [1, 4, 9])

# Zobrazenie grafu
st.pyplot(fig)