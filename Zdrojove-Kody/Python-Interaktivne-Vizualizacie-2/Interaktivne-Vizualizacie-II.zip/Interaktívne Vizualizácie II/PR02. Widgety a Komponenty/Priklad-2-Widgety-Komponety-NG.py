import streamlit as st
import pandas as pd
import datetime
import time
from PIL import Image

st.write(
    "# 🤯 1. Nadpis (Title)"
)



st.write(
    "# 🔠 2. Text (Text)"
)



st.write(
    "# ▶️ 3. Tlačidlo (Button)"
)



st.write(
    "# 🛝 4. Posuvník (slider)"
)



st.write(
    "# ✍ 5. Textový vstup (Text Input)"
)



st.write(
    "# ☑️ 6. Zaškrtávacie políčko. (Checkbox)"
)



st.write(
    "# 🔽 8. Rozbaľovací zoznam s možnosťami. (Selectbox)"
)



st.write(
    "# 📁 9. Upload súborov. (File uploader)"
)


st.write(
    "# 🔥 10. Upload CSV súborov. (File CSV uploader)"
)


st.write(
    "# 🏁 11. Upload obrázkov. (File image uploader)"
)



st.write(
    "# 📥 12. Tlačidlo na stiahnutie. (Download button)"
)



st.write(
    "# 📻 13. Výber jednej možnosti. (Radio)"
)

st.write(
    "# 📅 14. Výber dátumu. (Date input)"
)


st.write(
    "# 🕔 15. Výber času. (Time input)"
)



st.write(
    "# 🅰 16. Vstup dlhšieho textu. (Text area)"
)



st.write(
    "# 🔢 17. Vstup číselnej hodnoty. (Number Input)"
)



st.write(
    "# 🎚️ 18. Posuvník s výberom. (Select Slider)"
)



st.write(
    "# 🔴 19. Výber farby (Color picker)"
)



st.write(
    "# ⏳ 20. Indikátor progresu (Progress)"
)



st.write(
    "# 📐 21. Zobrazenie LaTeXu (matematické výrazy) (latex)"
)



st.write(
    "# 🌍 22. Zobrazenie kódu s formátovaním (code)"
)



st.write(
    "# 🌐 23. Zobrazenie JSON dát (json)"
)



st.write(
    "# ➡️ 24. Dynamický widget (všestranný) (write)"
)



st.write(
    "# 📏 25. Zobrazenie kľúčových metrik (metric)"
)



st.write(
    "# ❌ 26. Zobrazenie chybovej správy (error)"
)



st.write(
    "# ✅ 27. Zobrazenie úspešnej správy (success)"
)



st.write(
    "# ⚠️ 28. Zobrazenie varovnej správy (warning)"
)



st.write(
    "# 🆗 29. Zobrazenie informatívnej správy (info)"
)




st.write(
    "# ❗ 30. Zobrazenie výnimky (chyby v kóde) (exception)"
)



st.write(
    "# 🌀 31. Zobrazenie spinneru počas načítavania (spinner)"
)



st.write(
    "# 📝 32. Zobrazenie textovej poznámky (caption)"
)



st.write(
    "# 🖼️ 33. Zobrazenie obrázkov (image)"
)



st.write(
    "# 🎞️ 34. Zobrazenie videa/audio (video/audio)"
)



st.write(
    "# 🏛️ 35. Rozdelenie obrazovky do stĺpcov (columns)"
)


st.write(
    "# 📑 36. Vytváranie záložiek/tabov (tabs)"
)


st.write(
    "# 🚀 37. Rozbalovací blok (expander)"
)



st.write(
    "# 📈 38. Zobrazenie grafov v Matplotlib (pyplot)"
)

